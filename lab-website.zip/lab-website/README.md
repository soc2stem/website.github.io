# 🔬 Lab Website — GitHub Pages

A clean academic lab website with UT Austin branding. All content is managed from a single config file.

---

## 🚀 Getting Started (GitHub Pages)

### 1. Create your GitHub repo

1. Go to [github.com](https://github.com) and click **New Repository**
2. Name it: `your-username.github.io` (for a personal site) **or** any name (for a project site)
3. Set it to **Public**
4. Click **Create Repository**

### 2. Upload these files

**Option A — GitHub web interface (easiest):**
1. Open your new repo
2. Click **Add file → Upload files**
3. Drag the entire contents of this folder (all HTML, CSS, JS files + folders)
4. Click **Commit changes**

**Option B — Git command line:**
```bash
cd lab-website
git init
git add .
git commit -m "Initial lab website"
git remote add origin https://github.com/YOUR_USERNAME/YOUR_REPO.git
git push -u origin main
```

### 3. Enable GitHub Pages

1. In your repo, go to **Settings → Pages**
2. Under **Source**, select **Deploy from a branch**
3. Choose `main` branch, `/ (root)` folder
4. Click **Save**
5. Wait ~1 minute — your site will be live at `https://YOUR_USERNAME.github.io/YOUR_REPO/`

---

## ✏️ Editing Your Content

**Everything is controlled from one file: `js/config.js`**

Open it and update:

| Section | What to edit |
|---|---|
| `labName`, `department`, `university` | Lab identity |
| `tagline` | One-line mission |
| `email`, `address` | Contact info |
| `twitterHandle`, `githubOrg` | Social links |
| `hero` | Homepage headline & CTA |
| `news[]` | Announcements (newest first) |
| `researchAreas[]` | Research focus areas |
| `team[]` | Team members & bios |
| `publications[]` | Papers (auto-grouped by year) |

After editing, save the file and push to GitHub. The site updates automatically within ~30 seconds.

---

## 📁 File Structure

```
lab-website/
├── index.html          ← Home page
├── research.html       ← Research areas & projects
├── team.html           ← Team members (auto-grouped)
├── publications.html   ← Papers with tag filtering
├── contact.html        ← Contact info & joining info
├── css/
│   └── style.css       ← UT Austin theme + all styling
├── js/
│   ├── config.js       ← ⭐ EDIT THIS for all content
│   └── site.js         ← Shared nav/footer injection
└── images/             ← Put team photos here
    └── (your photos)
```

---

## 📸 Adding Team Photos

1. Add a photo file to the `images/` folder (e.g. `images/jane.jpg`)
2. In `config.js`, set the team member's `photo` field:
   ```js
   photo: "images/jane.jpg",
   ```

---

## ➕ Adding a New Page

1. Copy any existing `.html` file (e.g. `contact.html`)
2. Rename it (e.g. `outreach.html`)
3. In `config.js`, add it to `navLinks`:
   ```js
   { label: "Outreach", href: "outreach.html", visible: true },
   ```

---

## 🎨 Changing the Theme

Colors are defined in `css/style.css` at the top under `:root`. The UT Austin palette:

| Variable | Value | Use |
|---|---|---|
| `--orange` | `#BF5700` | Burnt Orange (primary) |
| `--orange-dark` | `#8C3D00` | Darker orange |
| `--charcoal` | `#2B2B2B` | Nav, text |
| `--cream` | `#FAF7F4` | Page background |
