/**
 * ============================================================
 *  LAB WEBSITE CONFIG — Edit everything here!
 *  Changes here will reflect across the whole site.
 * ============================================================
 */

const LAB_CONFIG = {

  // --- Lab Identity ---
  labName: "Computational Research Lab",
  labShortName: "CRL",
  department: "Department of Computer Science",
  university: "The University of Texas at Austin",
  tagline: "Advancing knowledge at the intersection of theory and application.",
  email: "lab@cs.utexas.edu",
  address: "Gates Dell Complex (GDC), Austin, TX 78712",
  twitterHandle: "@UTAustinCRL",   // or "" to hide
  githubOrg: "github.com/utcrl",   // or "" to hide
  googleScholar: "",               // paste full URL or "" to hide

  // --- Navigation Pages (set visible: false to hide a page) ---
  navLinks: [
    { label: "Home",         href: "index.html",        visible: true },
    { label: "Research",     href: "research.html",     visible: true },
    { label: "Team",         href: "team.html",         visible: true },
    { label: "Publications", href: "publications.html", visible: true },
    { label: "Contact",      href: "contact.html",      visible: true },
  ],

  // --- Home Page Hero ---
  hero: {
    headline: "Pushing the Frontiers of Computational Science",
    subtext:  "We develop novel algorithms, systems, and theories that bridge fundamental research and real-world impact.",
    ctaLabel:  "Explore Our Research",
    ctaHref:   "research.html",
  },

  // --- Home Page News/Announcements (newest first) ---
  news: [
    { date: "June 2026",     text: "Our paper on distributed optimization was accepted to NeurIPS 2026." },
    { date: "May 2026",      text: "Dr. Jane Smith receives the NSF CAREER Award." },
    { date: "March 2026",    text: "We welcome three new PhD students to the lab!" },
  ],

  // --- Research Areas ---
  researchAreas: [
    {
      title: "Machine Learning Theory",
      description: "We study the theoretical foundations of learning algorithms, with a focus on generalization, robustness, and sample complexity.",
      icon: "🧠",
    },
    {
      title: "Distributed Systems",
      description: "Designing scalable, fault-tolerant systems for large-scale data processing and scientific computing.",
      icon: "🔗",
    },
    {
      title: "Human-Computer Interaction",
      description: "Building interfaces that make complex computational tools accessible to domain scientists and practitioners.",
      icon: "🖥️",
    },
  ],

  // --- Team Members ---
  team: [
    {
      name:     "Dr. Jane Smith",
      role:     "Principal Investigator",
      bio:      "Jane received her PhD from MIT and joined UT Austin in 2018. Her research focuses on ML theory and optimization.",
      photo:    "",            // path to photo, e.g. "images/jane.jpg", or "" for initials avatar
      website:  "",
      scholar:  "",
      github:   "",
      group:    "Faculty",     // used to group members: Faculty | PhD Students | MS Students | Alumni
    },
    {
      name:     "Alex Johnson",
      role:     "PhD Student",
      bio:      "Alex is a 3rd-year PhD student working on distributed optimization algorithms.",
      photo:    "",
      website:  "",
      scholar:  "",
      github:   "",
      group:    "PhD Students",
    },
    {
      name:     "Maria Garcia",
      role:     "PhD Student",
      bio:      "Maria's research sits at the intersection of HCI and ML, building tools for scientific discovery.",
      photo:    "",
      website:  "",
      scholar:  "",
      github:   "",
      group:    "PhD Students",
    },
    {
      name:     "Chris Lee",
      role:     "MS Student",
      bio:      "Chris is working on his thesis on efficient neural architecture search.",
      photo:    "",
      website:  "",
      scholar:  "",
      github:   "",
      group:    "MS Students",
    },
  ],

  // --- Publications (newest first) ---
  publications: [
    {
      title:   "Convergence Rates for Stochastic Gradient Methods under Heavy-Tail Noise",
      authors: "Smith, J., Johnson, A., Garcia, M.",
      venue:   "NeurIPS 2026",
      year:    2026,
      tags:    ["ML Theory"],
      pdf:     "",    // URL to PDF
      code:    "",    // URL to code repo
      doi:     "",    // DOI URL
    },
    {
      title:   "FaultShield: Transparent Fault Tolerance for Distributed ML Training",
      authors: "Johnson, A., Smith, J.",
      venue:   "OSDI 2025",
      year:    2025,
      tags:    ["Distributed Systems"],
      pdf:     "",
      code:    "",
      doi:     "",
    },
    {
      title:   "SciLens: An Interactive Environment for Exploratory Data Analysis",
      authors: "Garcia, M., Lee, C., Smith, J.",
      venue:   "CHI 2025",
      year:    2025,
      tags:    ["HCI"],
      pdf:     "",
      code:    "",
      doi:     "",
    },
  ],

};
