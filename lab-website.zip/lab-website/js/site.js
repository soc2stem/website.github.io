/**
 * site.js — Injects shared nav/header/footer from config.js
 * Runs on every page.
 */

(function () {
  const cfg = LAB_CONFIG;

  // ── Header / Nav ────────────────────────────────────────
  const currentPage = location.pathname.split('/').pop() || 'index.html';

  const navItems = cfg.navLinks
    .filter(l => l.visible)
    .map(l => {
      const active = (l.href === currentPage || (currentPage === '' && l.href === 'index.html')) ? ' class="active"' : '';
      return `<li><a href="${l.href}"${active}>${l.label}</a></li>`;
    }).join('');

  const header = document.getElementById('site-header');
  if (header) {
    header.innerHTML = `
      <div class="header-inner">
        <a class="site-title" href="index.html">
          <span>${cfg.labShortName}</span> — ${cfg.university.replace('The University of Texas at Austin', 'UT Austin')}
        </a>
        <button class="nav-toggle" aria-label="Toggle navigation" onclick="this.parentElement.parentElement.querySelector('nav').classList.toggle('open')">
          <span></span><span></span><span></span>
        </button>
        <nav id="site-nav"><ul>${navItems}</ul></nav>
      </div>
    `;
  }

  // ── Footer ───────────────────────────────────────────────
  const footer = document.getElementById('site-footer');
  if (footer) {
    const socials = [
      cfg.twitterHandle ? `<a href="https://twitter.com/${cfg.twitterHandle.replace('@','')}" target="_blank">${cfg.twitterHandle}</a>` : null,
      cfg.githubOrg     ? `<a href="https://${cfg.githubOrg}" target="_blank">GitHub</a>` : null,
      cfg.googleScholar ? `<a href="${cfg.googleScholar}" target="_blank">Google Scholar</a>` : null,
    ].filter(Boolean).join(' · ');

    footer.innerHTML = `
      <p>${cfg.labName} · ${cfg.department} · ${cfg.university}</p>
      <p style="margin-top:6px">${cfg.address} · <a href="mailto:${cfg.email}">${cfg.email}</a></p>
      ${socials ? `<p style="margin-top:8px">${socials}</p>` : ''}
      <p style="margin-top:10px; color:#666">© ${new Date().getFullYear()} ${cfg.labName}. Built with GitHub Pages.</p>
    `;
  }
})();
